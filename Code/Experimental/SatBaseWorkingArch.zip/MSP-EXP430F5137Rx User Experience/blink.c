//***************************************************************************************
//  MSP430 Blink the LED Demo - Software Toggle P1.0
//
//  Description; Toggle P1.0 by xor'ing P1.0 inside of a software loop.
//  ACLK = n/a, MCLK = SMCLK = default DCO
//
//                MSP430x5xx
//             -----------------
//         /|\|              XIN|-
//          | |                 |
//          --|RST          XOUT|-
//            |                 |
//            |             P1.0|-->LED
//
//  J. Stevenson
//  Texas Instruments, Inc
//  July 2011
//  Built with Code Composer Studio v5
//***************************************************************************************

#include <msp430.h>				

int Blink(void) {
	//WDTCTL = WDTPW | WDTHOLD;		// Stop watchdog timer



	//P1DIR |= 0x01;					// Set P1.1 - 1.4 to output direction
	P1DIR |= 0x02;
	P1DIR |= 0x04;
	P1DIR |= 0x08;
	P1DIR |= 0x10;

	P2SEL &= 0xfb;
	P2DIR &= 0xfb;
	P2REN |= 0x04;
	P2OUT |= 0x04;
	int test = 1;
	char P2State = P2IN;


	for(;;) {
		volatile unsigned int i;	// volatile to prevent optimization
		volatile unsigned int j;
		//P1OUT ^= 0x01;				// Toggle P1.0 using exclusive-OR
		while(test){
					if (P2State!=P2IN) test = 0;
				}
				test = 1;


		P1OUT ^= 0x02;
		P1OUT ^= 0x04;
		P1OUT ^= 0x08;
		P1OUT ^= 0x10;


		for(int i = 0; i<30000; i++)
		{
			for(int j = 0; j<2; j++)
					{
					}

		}

	}
	
	return 0;
}
